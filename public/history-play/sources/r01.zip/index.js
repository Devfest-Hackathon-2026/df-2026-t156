import http from 'node:http';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { WebSocketServer, WebSocket } from 'ws';
import { World, RULES } from './game.js';
import { serveBuild } from './static.js';

export function createGameServer({ staticDir, world = new World() } = {}) {
  const directory = staticDir || process.env.STATIC_DIR || fileURLToPath(new URL('../Unity/Builds/WebGL', import.meta.url));
  const staticHandler = serveBuild(directory);
  const server = http.createServer((req, res) => {
    if (new URL(req.url, 'http://local').pathname === '/health') {
      res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
      res.end(JSON.stringify({ ok: true, round: world.round, phase: world.phase,
        players: [...world.players.values()].filter(p => !p.bot).length }));
    } else staticHandler(req, res).catch(() => { if (!res.headersSent) res.writeHead(500); res.end(); });
  });
  const wss = new WebSocketServer({ server, path: '/ws', maxPayload: 2048, perMessageDeflate: false });
  const send = (socket, packet) => {
    if (socket.readyState === WebSocket.OPEN && socket.bufferedAmount < 256 * 1024)
      socket.send(typeof packet === 'string' ? packet : JSON.stringify(packet));
  };
  wss.on('connection', socket => {
    let id, received = 0, windowStart = Date.now();
    const joinedBy = setTimeout(() => { if (!id) socket.close(1008, 'Join required'); }, 10000);
    socket.alive = true;
    socket.on('pong', () => { socket.alive = true; });
    socket.on('message', (bytes, binary) => {
      if (binary) { socket.close(1003, 'JSON text required'); return; }
      if (Date.now() - windowStart > 1000) { windowStart = Date.now(); received = 0; }
      if (++received > 80) { socket.close(1008, 'Input rate exceeded'); return; }
      let packet;
      try { packet = JSON.parse(bytes.toString()); } catch { socket.close(1007, 'Invalid JSON'); return; }
      if (!packet || typeof packet !== 'object' || Array.isArray(packet)) return;
      if (packet.type === 'join' && !id) {
        if ([...world.players.values()].filter(p => !p.bot).length >= RULES.maxHumans) {
          send(socket, { type: 'error', message: 'Room full' }); socket.close(1013, 'Room full'); return;
        }
        id = randomUUID();
        const name = typeof packet.name === 'string' ? packet.name.replace(/[\x00-\x1f\x7f<>]/g, '').trim().slice(0, 18) : '';
        world.addPlayer(id, name || 'PILOT');
        clearTimeout(joinedBy);
        send(socket, { type: 'welcome', id });
        send(socket, world.snapshot());
      } else if (packet.type === 'input' && id) world.input(id, packet);
    });
    socket.on('error', () => {});
    socket.on('close', () => { clearTimeout(joinedBy); if (id) world.removePlayer(id); });
  });
  const timer = setInterval(() => {
    if (![...world.players.values()].some(p => !p.bot)) return;
    world.tick(1 / RULES.tickRate);
    const snapshot = JSON.stringify(world.snapshot());
    for (const socket of wss.clients) send(socket, snapshot);
  }, 1000 / RULES.tickRate);
  const heartbeat = setInterval(() => {
    for (const socket of wss.clients) {
      if (!socket.alive) { socket.terminate(); continue; }
      socket.alive = false; socket.ping();
    }
  }, 10000);
  const stop = async () => {
    clearInterval(timer); clearInterval(heartbeat);
    for (const socket of wss.clients) socket.terminate();
    await new Promise(resolve => wss.close(resolve));
    if (server.listening) await new Promise(resolve => server.close(resolve));
  };
  return { server, wss, world, stop };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT || 8080);
  if (!Number.isInteger(port) || port < 0 || port > 65535) throw new Error('Invalid PORT');
  const app = createGameServer();
  app.server.listen(port, process.env.HOST || '0.0.0.0', () =>
    console.log(`Orbit Salvage listening on port ${app.server.address().port}`));
  for (const signal of ['SIGINT', 'SIGTERM']) process.once(signal, () => app.stop().then(() => process.exit(0)));
}
