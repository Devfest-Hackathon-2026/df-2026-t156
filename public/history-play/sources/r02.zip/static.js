import { createReadStream } from 'node:fs';
import { stat } from 'node:fs/promises';
import path from 'node:path';

const types = {
  '.html': 'text/html; charset=utf-8', '.js': 'application/javascript',
  '.css': 'text/css', '.json': 'application/json', '.wasm': 'application/wasm',
  '.data': 'application/octet-stream', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
  '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg', '.wav': 'audio/wav',
};

export function serveBuild(directory) {
  const root = path.resolve(directory);
  return async (req, res) => {
    if (!['GET', 'HEAD'].includes(req.method)) {
      res.writeHead(405, { Allow: 'GET, HEAD' }).end();
      return;
    }
    let pathname;
    try { pathname = decodeURIComponent(new URL(req.url, 'http://local').pathname); }
    catch { res.writeHead(400).end('Invalid path'); return; }
    if (pathname.includes('\0') || pathname.includes('\\')) {
      res.writeHead(400).end('Invalid path'); return;
    }
    const target = path.resolve(root, '.' + pathname, pathname.endsWith('/') ? 'index.html' : '');
    if (target !== root && !target.startsWith(root + path.sep)) {
      res.writeHead(403).end(); return;
    }
    try {
      const info = await stat(target);
      if (!info.isFile()) { res.writeHead(404).end('Not found'); return; }
      let logicalName = target;
      const headers = { 'Content-Length': info.size, 'Cache-Control': 'no-cache' };
      if (target.endsWith('.br') || target.endsWith('.gz')) {
        headers['Content-Encoding'] = target.endsWith('.br') ? 'br' : 'gzip';
        logicalName = target.slice(0, -3);
      } else if (target.endsWith('.unityweb')) logicalName = target.slice(0, -9);
      headers['Content-Type'] = types[path.extname(logicalName)] || 'application/octet-stream';
      res.writeHead(200, headers);
      if (req.method === 'HEAD') res.end();
      else createReadStream(target).on('error', () => res.destroy()).pipe(res);
    } catch {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' })
        .end('Unity WebGL build not found. Set STATIC_DIR to the build folder.');
    }
  };
}
